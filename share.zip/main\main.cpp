#include "pins.hpp"
#include "freertos/FreeRTOS.h"

extern "C" [[noreturn]] auto app_main() -> void {
    // Heart beat
    constexpr gpio_config_t heart_beat_led{
        .pin_bit_mask{1ULL << p2},
        .mode{GPIO_MODE_OUTPUT},
    };
    gpio_config(&heart_beat_led);

    while (true) {
        gpio_set_level(p2, 1);
        vTaskDelay(pdMS_TO_TICKS(1000));
        gpio_set_level(p2, 0);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
