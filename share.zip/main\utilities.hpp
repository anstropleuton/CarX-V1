#pragma once

#include <algorithm>
#include <cassert>
#include <cstddef>
#include <functional>
#include <initializer_list>
#include <iterator>
#include <new>
#include <string_view>
#include <type_traits>
#include <utility>

template <typename type, std::size_t cap>
struct inplace_vector {
    type        storage[cap]{};
    std::size_t count{};

    inplace_vector() = default;

    explicit inplace_vector(std::size_t const count)
        : count(count) {
        assert(count <= cap);
    }

    inplace_vector(std::size_t const count, type const &value)
        : count(count) {
        assert(count <= cap);
        for (std::size_t index{}; index < count; ++index) storage[index] = value;
    }

    inplace_vector(std::initializer_list<type> init) {
        assert(init.size() <= cap);
        for (auto const &value : init) storage[count++] = value;
    }

    auto push_back(type const &value) {
        assert(count < cap);
        storage[count++] = value;
    }

    auto pop_back() {
        assert(count > 0);
        --count;
    }

    template <typename... args>
    auto emplace_back(args &&... values) -> type & {
        assert(count < cap);

        if constexpr (sizeof...(args) == 0)
            return storage[count++];
        else {
            storage[count] = type(std::forward<args>(values)...);
            return storage[count++];
        }
    }

    auto resize(std::size_t const new_count) {
        assert(new_count <= cap);

        if (new_count > count)
            for (std::size_t index{count}; index < new_count; ++index)
                storage[index] = type{};

        count = new_count;
    }

    auto resize(std::size_t const new_count, type const &value) {
        assert(new_count <= cap);

        for (std::size_t index{count}; index < new_count; ++index)
            storage[index] = value;

        count = new_count;
    }

    auto clear() { count = 0; }

    [[nodiscard]] auto operator[](std::size_t const index) -> type & { return storage[index]; }
    [[nodiscard]] auto operator[](std::size_t const index) const -> type const & { return storage[index]; }

    [[nodiscard]] auto at(std::size_t index) -> type & {
        assert(index < count);
        return storage[index];
    }

    [[nodiscard]] auto at(std::size_t index) const -> type const & {
        assert(index < count);
        return storage[index];
    }

    [[nodiscard]] auto begin() -> type * { return storage; }
    [[nodiscard]] auto end() -> type * { return storage + count; }
    [[nodiscard]] auto begin() const -> type const * { return storage; }
    [[nodiscard]] auto end() const -> type const * { return storage + count; }

    [[nodiscard]] auto rbegin() { return std::reverse_iterator(end()); }
    [[nodiscard]] auto rend() { return std::reverse_iterator(begin()); }

    [[nodiscard]] auto rbegin() const { return std::reverse_iterator(end()); }
    [[nodiscard]] auto rend() const { return std::reverse_iterator(begin()); }

    [[nodiscard]] auto data() -> type * { return storage; }
    [[nodiscard]] auto data() const -> type const * { return storage; }

    [[nodiscard]] auto front() -> type & {
        assert(count > 0);
        return storage[0];
    }

    [[nodiscard]] auto front() const -> type const & {
        assert(count > 0);
        return storage[0];
    }

    [[nodiscard]] auto back() -> type & {
        assert(count > 0);
        return storage[count - 1];
    }

    [[nodiscard]] auto back() const -> type const & {
        assert(count > 0);
        return storage[count - 1];
    }

    [[nodiscard]] auto                  size() const { return count; }
    [[nodiscard]] static constexpr auto capacity() { return cap; }
    [[nodiscard]] auto                  empty() const { return count == 0; }
    [[nodiscard]] auto                  full() const { return count == cap; }
    [[nodiscard]] auto                  remaining() const { return cap - count; }
};

template <typename type, typename... rest>
inplace_vector(type, rest...) -> inplace_vector<type, 1 + sizeof...(rest)>;

template <typename type, std::size_t cap1, std::size_t cap2>
auto operator==(inplace_vector<type, cap1> const &a, inplace_vector<type, cap2> const &b) {
    if (a.count != b.count)
        return false;

    for (std::size_t index{}; index < a.count; ++index)
        if (!(a[index] == b[index]))
            return false;

    return true;
}

template <std::size_t cap, typename char_type = char>
struct inplace_basic_string {
    using traits = std::char_traits<char_type>;
    using view   = std::basic_string_view<char_type>;

    static constexpr std::size_t npos{view::npos};

    char_type   storage[cap + 1]{};
    std::size_t count{};

    inplace_basic_string() = default;

    inplace_basic_string(std::size_t const count, char_type const value) {
        assign(count, value);
    }

    explicit inplace_basic_string(char_type const *text) {
        assign(view{text});
    }

    explicit inplace_basic_string(view const text) {
        assign(text);
    }

    inplace_basic_string(std::initializer_list<char_type> init) {
        assign(view{init.begin(), init.size()});
    }

    template <std::input_iterator iterator>
    inplace_basic_string(iterator first, iterator last) {
        for (; first != last; ++first) push_back(*first);
    }

    explicit operator view() const noexcept { return view{storage, count}; }

    auto assign(view const text) -> inplace_basic_string & {
        assert(text.size() <= cap);
        traits::move(storage, text.data(), text.size());
        count = text.size();
        terminate();
        return *this;
    }

    auto assign(std::size_t const new_count, char_type const value) -> inplace_basic_string & {
        assert(new_count <= cap);
        traits::assign(storage, new_count, value);
        count = new_count;
        terminate();
        return *this;
    }

    auto operator=(view const text) -> inplace_basic_string & { return assign(text); }
    auto operator=(char_type const *text) -> inplace_basic_string & { return assign(view{text}); }
    auto operator=(char_type const value) -> inplace_basic_string & { return assign(1, value); }

    [[nodiscard]] auto operator[](std::size_t const index) -> char_type & { return storage[index]; }
    [[nodiscard]] auto operator[](std::size_t const index) const -> char_type const & { return storage[index]; }

    [[nodiscard]] auto at(std::size_t const index) -> char_type & {
        assert(index < count);
        return storage[index];
    }

    [[nodiscard]] auto at(std::size_t const index) const -> char_type const & {
        assert(index < count);
        return storage[index];
    }

    [[nodiscard]] auto front() -> char_type & {
        assert(count > 0);
        return storage[0];
    }

    [[nodiscard]] auto front() const -> char_type const & {
        assert(count > 0);
        return storage[0];
    }

    [[nodiscard]] auto back() -> char_type & {
        assert(count > 0);
        return storage[count - 1];
    }

    [[nodiscard]] auto back() const -> char_type const & {
        assert(count > 0);
        return storage[count - 1];
    }

    [[nodiscard]] auto data() -> char_type * { return storage; }
    [[nodiscard]] auto data() const -> char_type const * { return storage; }
    [[nodiscard]] auto c_str() const -> char_type const * { return storage; }

    [[nodiscard]] auto begin() -> char_type * { return storage; }
    [[nodiscard]] auto end() -> char_type * { return storage + count; }
    [[nodiscard]] auto begin() const -> char_type const * { return storage; }
    [[nodiscard]] auto end() const -> char_type const * { return storage + count; }
    [[nodiscard]] auto cbegin() const -> char_type const * { return begin(); }
    [[nodiscard]] auto cend() const -> char_type const * { return end(); }

    [[nodiscard]] auto rbegin() { return std::reverse_iterator(end()); }
    [[nodiscard]] auto rend() { return std::reverse_iterator(begin()); }

    [[nodiscard]] auto rbegin() const { return std::reverse_iterator(end()); }
    [[nodiscard]] auto rend() const { return std::reverse_iterator(begin()); }

    [[nodiscard]] auto                  size() const { return count; }
    [[nodiscard]] auto                  length() const { return count; }
    [[nodiscard]] static constexpr auto capacity() { return cap; }
    [[nodiscard]] static constexpr auto max_size() { return cap; }
    [[nodiscard]] auto                  empty() const { return count == 0; }
    [[nodiscard]] auto                  full() const { return count == cap; }
    [[nodiscard]] auto                  remaining() const { return cap - count; }

    auto clear() {
        count = 0;
        terminate();
    }

    auto push_back(char_type const value) {
        assert(count < cap);
        storage[count++] = value;
        terminate();
    }

    auto pop_back() {
        assert(count > 0);
        --count;
        terminate();
    }

    template <typename... args>
    auto emplace_back(args &&... values) -> char_type & {
        assert(count < cap);
        auto &slot = storage[count++];
        slot       = char_type(std::forward<args>(values)...);
        terminate();
        return slot;
    }

    auto resize(std::size_t const new_count, char_type const value = char_type{}) {
        assert(new_count <= cap);

        if (new_count > count)
            traits::assign(storage + count, new_count - count, value);

        count = new_count;
        terminate();
    }

    auto append(view const text) -> inplace_basic_string & {
        assert(text.size() <= remaining());
        traits::move(storage + count, text.data(), text.size());
        count += text.size();
        terminate();
        return *this;
    }

    auto append(std::size_t const append_count, char_type const value) -> inplace_basic_string & {
        assert(append_count <= remaining());
        traits::assign(storage + count, append_count, value);
        count += append_count;
        terminate();
        return *this;
    }

    auto operator+=(view const text) -> inplace_basic_string & { return append(text); }
    auto operator+=(char_type const *text) -> inplace_basic_string & { return append(view{text}); }
    auto operator+=(char_type const value) -> inplace_basic_string & { return append(1, value); }

    auto insert(std::size_t const index, view const text) -> inplace_basic_string & {
        assert(index <= count);
        assert(text.size() <= remaining());
        traits::move(storage + index + text.size(), storage + index, count - index);
        traits::copy(storage + index, text.data(), text.size());
        count += text.size();
        terminate();
        return *this;
    }

    auto insert(
        std::size_t const index,
        std::size_t const insert_count,
        char_type const   value
    ) -> inplace_basic_string & {
        assert(index <= count);
        assert(insert_count <= remaining());
        traits::move(storage + index + insert_count, storage + index, count - index);
        traits::assign(storage + index, insert_count, value);
        count += insert_count;
        terminate();
        return *this;
    }

    auto erase(std::size_t const index = 0, std::size_t erase_count = npos) -> inplace_basic_string & {
        assert(index <= count);
        erase_count = std::min(erase_count, count - index);
        traits::move(storage + index, storage + index + erase_count, count - index - erase_count);
        count -= erase_count;
        terminate();
        return *this;
    }

    auto replace(std::size_t const index, std::size_t replace_count, view const text) -> inplace_basic_string & {
        assert(index <= count);
        replace_count = std::min(replace_count, count - index);
        assert(count - replace_count + text.size() <= cap);
        traits::move(storage + index + text.size(), storage + index + replace_count, count - index - replace_count);
        traits::copy(storage + index, text.data(), text.size());
        count = count - replace_count + text.size();
        terminate();
        return *this;
    }

    [[nodiscard]] auto substr(
        std::size_t const position     = 0,
        std::size_t const substr_count = npos
    ) const -> inplace_basic_string {
        assert(position <= count);
        return inplace_basic_string{view{*this}.substr(position, substr_count)};
    }

    [[nodiscard]] auto compare(view const text) const -> int { return view{*this}.compare(text); }

    [[nodiscard]] auto starts_with(view const text) const { return view{*this}.starts_with(text); }
    [[nodiscard]] auto starts_with(char_type const value) const { return view{*this}.starts_with(value); }
    [[nodiscard]] auto ends_with(view const text) const { return view{*this}.ends_with(text); }
    [[nodiscard]] auto ends_with(char_type const value) const { return view{*this}.ends_with(value); }
    [[nodiscard]] auto contains(view const text) const { return view{*this}.contains(text); }
    [[nodiscard]] auto contains(char_type const value) const { return view{*this}.contains(value); }

    [[nodiscard]] auto find(view const text, std::size_t const position = 0) const {
        return view{*this}.find(text, position);
    }

    [[nodiscard]] auto find(char_type const value, std::size_t const position = 0) const {
        return view{*this}.find(value, position);
    }

    [[nodiscard]] auto rfind(view const text, std::size_t const position = npos) const {
        return view{*this}.rfind(text, position);
    }

    [[nodiscard]] auto rfind(char_type const value, std::size_t const position = npos) const {
        return view{*this}.rfind(value, position);
    }

    [[nodiscard]] auto find_first_of(view const characters, std::size_t const position = 0) const {
        return view{*this}.find_first_of(characters, position);
    }

    [[nodiscard]] auto find_last_of(view const characters, std::size_t const position = npos) const {
        return view{*this}.find_last_of(characters, position);
    }

    [[nodiscard]] auto find_first_not_of(view const characters, std::size_t const position = 0) const {
        return view{*this}.find_first_not_of(characters, position);
    }

    [[nodiscard]] auto find_last_not_of(view const characters, std::size_t const position = npos) const {
        return view{*this}.find_last_not_of(characters, position);
    }

    [[nodiscard]] friend auto operator==(inplace_basic_string const &a, view const b) { return view{a} == b; }
    [[nodiscard]] friend auto operator<=>(inplace_basic_string const &a, view const b) { return view{a} <=> b; }

private:
    auto terminate() { storage[count] = char_type{}; }
};

template <std::size_t cap1, std::size_t cap2, typename char_type>
[[nodiscard]] auto operator==(
    inplace_basic_string<cap1, char_type> const &a,
    inplace_basic_string<cap2, char_type> const &b
) {
    return std::basic_string_view<char_type>{a} == std::basic_string_view<char_type>{b};
}

template <std::size_t cap1, std::size_t cap2, typename char_type>
[[nodiscard]] auto operator<=>(
    inplace_basic_string<cap1, char_type> const &a,
    inplace_basic_string<cap2, char_type> const &b
) {
    return std::basic_string_view<char_type>{a} <=> std::basic_string_view<char_type>{b};
}

template <std::size_t cap1, std::size_t cap2, typename char_type>
[[nodiscard]] auto operator+(
    inplace_basic_string<cap1, char_type> const &a,
    inplace_basic_string<cap2, char_type> const &b
) {
    inplace_basic_string<cap1 + cap2, char_type> result{std::basic_string_view<char_type>{a}};
    result += std::basic_string_view<char_type>{b};
    return result;
}

template <std::size_t cap>
using inplace_string = inplace_basic_string<cap>;

template <std::size_t cap>
using inplace_wstring = inplace_basic_string<cap, wchar_t>;

template <std::size_t cap>
using inplace_u8string = inplace_basic_string<cap, char8_t>;

template <typename char_type, std::size_t size>
inplace_basic_string(char_type const (&)[size]) -> inplace_basic_string<size - 1, char_type>;

template <typename signature, std::size_t cap = sizeof(void *) * 4, std::size_t align = alignof(std::max_align_t)>
struct inplace_function;

template <typename ret, typename... args, std::size_t cap, std::size_t align>
struct inplace_function<ret(args...), cap, align> {
    using invoke_fn  = ret (*)(void *, args...);
    using copy_fn    = void (*)(void *, void const *);
    using move_fn    = void (*)(void *, void *) noexcept;
    using destroy_fn = void (*)(void *) noexcept;

    struct vtable {
        invoke_fn  invoke{};
        copy_fn    copy{};
        move_fn    move{};
        destroy_fn destroy{};
    };

    alignas(align) mutable std::byte storage[cap]{};
    vtable const *                   table{};

    template <typename callable>
    static constexpr bool fits{
        sizeof(callable) <= cap && alignof(callable) <= align && align % alignof(callable) == 0
    };

    inplace_function() = default;
    explicit inplace_function(std::nullptr_t) {}

    inplace_function(inplace_function const &other) { copy_from(other); }
    inplace_function(inplace_function &&other) noexcept { move_from(other); }

    template <typename callable, typename decayed = std::decay_t<callable>>
        requires(!std::is_same_v<decayed, inplace_function> && std::is_invocable_r_v<ret, decayed &, args...>)
    explicit inplace_function(callable &&value) {
        emplace<decayed>(std::forward<callable>(value));
    }

    ~inplace_function() { reset(); }

    auto operator=(inplace_function const &other) -> inplace_function & {
        if (this != &other) {
            reset();
            copy_from(other);
        }
        return *this;
    }

    auto operator=(inplace_function &&other) noexcept -> inplace_function & {
        if (this != &other) {
            reset();
            move_from(other);
        }
        return *this;
    }

    auto operator=(std::nullptr_t) noexcept -> inplace_function & {
        reset();
        return *this;
    }

    template <typename callable, typename decayed = std::decay_t<callable>>
        requires(!std::is_same_v<decayed, inplace_function> && std::is_invocable_r_v<ret, decayed &, args...>)
    auto operator=(callable &&value) -> inplace_function & {
        emplace<decayed>(std::forward<callable>(value));
        return *this;
    }

    template <typename callable, typename... params>
    auto emplace(params &&... values) -> callable & {
        static_assert(fits<callable>, "callable does not fit in inplace_function storage");
        static_assert(std::is_nothrow_move_constructible_v<callable>, "callable must be nothrow move constructible");
        static_assert(std::is_invocable_r_v<ret, callable &, args...>, "callable is not invocable with this signature");

        reset();
        auto *object = ::new(static_cast<void *>(storage)) callable(std::forward<params>(values)...);
        table        = table_for<callable>();
        return *object;
    }

    auto reset() noexcept {
        if (table) {
            table->destroy(storage);
            table = nullptr;
        }
    }

    auto operator()(args... values) const -> ret {
        assert(table);
        return table->invoke(storage, std::forward<args>(values)...);
    }

    [[nodiscard]] explicit operator bool() const noexcept { return table != nullptr; }
    [[nodiscard]] auto     empty() const noexcept { return table == nullptr; }

    [[nodiscard]] static constexpr auto capacity() { return cap; }

    [[nodiscard]] friend auto operator==(inplace_function const &f, std::nullptr_t) noexcept { return f.empty(); }

private:
    template <typename callable>
    static auto invoke_impl(void *self, args... values) -> ret {
        return std::invoke(*static_cast<callable *>(self), std::forward<args>(values)...);
    }

    template <typename callable>
    static auto copy_impl(void *destination, void const *source) {
        ::new(destination) callable(*static_cast<callable const *>(source));
    }

    template <typename callable>
    static auto move_impl(void *destination, void *source) noexcept {
        ::new(destination) callable(std::move(*static_cast<callable *>(source)));
    }

    template <typename callable>
    static auto destroy_impl(void *self) noexcept {
        static_cast<callable *>(self)->~callable();
    }

    template <typename callable>
    static constexpr auto copy_for() -> copy_fn {
        if constexpr (std::is_copy_constructible_v<callable>)
            return &copy_impl<callable>;
        else
            return nullptr;
    }

    template <typename callable>
    static auto table_for() -> vtable const * {
        static constexpr vtable value{
            &invoke_impl<callable>,
            copy_for<callable>(),
            &move_impl<callable>,
            &destroy_impl<callable>,
        };
        return &value;
    }

    auto copy_from(inplace_function const &other) {
        if (other.table == nullptr)
            return;

        assert(other.table->copy && "callable is not copy constructible");
        other.table->copy(storage, other.storage);
        table = other.table;
    }

    auto move_from(inplace_function &other) noexcept {
        if (other.table == nullptr)
            return;

        other.table->move(storage, other.storage);
        table = other.table;
        other.reset();
    }
};
